
public class Product {
	int peso;
	int id;

	Product(int id, int peso) {
		this.id = id;
		this.peso = peso;
	}
}
