
public class Position {
	int R;
	int C;

	Position(int r, int c) {
		this.R = r;
		this.C = c;
	}

}
